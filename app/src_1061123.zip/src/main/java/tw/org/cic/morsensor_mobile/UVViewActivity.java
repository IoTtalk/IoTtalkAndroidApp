package tw.org.cic.morsensor_mobile;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import tw.org.cic.dataManage.DataTransform;
import tw.org.cic.dataManage.MorSensorParameter;

public class UVViewActivity extends Activity {


    private static String TAG = "UVViewActivity";
    public static Context mContext;
    public Activity mUVViewActivity;
    public static TextView tvUVIndex, tvUVInfo;

    private ArrayAdapter<String> adapter;
    private static final String[] spinner_alert_index_list = {"1", "2", "3", "4", "5"};
    private static final String[] spinner_alert_time_list = {"5", "10", "15", "30", "60"};

    LinearLayout linearInfo, linearInfoSet;
    public static ImageView imgInfoIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_uvview);


        mContext = this;
        mUVViewActivity = this;


        RelativeLayout relativeBG = (RelativeLayout) findViewById(R.id.relativeBG);
//        DataTransform.setRelativeLayout(mContext, relativeBG, R.drawable.mobile_bg_1);

        ImageButton imgMain = (ImageButton) findViewById(R.id.imgMain);
        imgMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, MainViewActivity.class);
                startActivity(intent);
            }
        });
        ImageView imgInfo = (ImageView) findViewById(R.id.imgInfo);
//        DataTransform.setImageViewDrawable(mContext, imgMain, R.drawable.mobile_uv_main);
//        DataTransform.setImageViewDrawable(mContext, imgInfo, R.drawable.mobile_main_information_ch_1);


        linearInfo = (LinearLayout) findViewById(R.id.linearInfo);
        linearInfoSet = (LinearLayout) findViewById(R.id.linearInfoSet);
        linearInfo.setVisibility(View.VISIBLE);
        linearInfoSet.setVisibility(View.INVISIBLE);

        int color = (255 & 0xff) << 24 | (0 & 0xff) << 16 | (0 & 0xff) << 8 | (0 & 0xff); //A R G B
        tvUVIndex = (TextView) findViewById(R.id.tvUVIndex);
        tvUVIndex.setTextColor(color);

        imgInfoIndex = (ImageView) findViewById(R.id.imgInfoIndex);
//        DataTransform.setImageViewDrawable(mContext, imgInfoIndex, R.drawable.mobile_uv_circle_05_ch);

        tvUVInfo = (TextView) findViewById(R.id.tvUVInfo);
        tvUVInfo.setMovementMethod(ScrollingMovementMethod.getInstance());


        ImageButton imgbtnSave = (ImageButton) findViewById(R.id.imgbtnSave);
        imgbtnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //防曬警示設定
                    if (cb_protection_alert_index.isChecked()) {
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "PROTECTION_ALERT_INDEX_ON_OFF"); //OFF ON
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "" + protection_alert_index, "PROTECTION_ALERT_INDEX");
                    } else
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "PROTECTION_ALERT_INDEX_ON_OFF"); //OFF ON

                    //防護提醒設定
                    if (cb_protection_alert_time.isChecked()) {
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "PROTECTION_ALERT_TIME_ON_OFF"); //OFF ON
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "" + protection_alert_time, "PROTECTION_ALERT_TIME");
                    } else
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "PROTECTION_ALERT_TIME_ON_OFF"); //OFF ON

                    Log.i(TAG, "imgbtnSave protection_alert_index:"+protection_alert_index+"    protection_alert_time:"+protection_alert_time);
                    //預警時間
                    if (cb_warning.isChecked()) {
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "WARNING_ON_OFF"); //OFF ON
                        if (cb_warning_time.isChecked()) {
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "TIME", "WARNING_TIME_DAY"); //OFF Time Day
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "" + warning_hour, "WARNING_HOUR");
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "" + warning_minutes, "WARNING_MINUTES");
                        } else if (cb_warning_day.isChecked())
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "DAY", "WARNING_TIME_DAY"); //OFF Time Day
                        else
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "WARNING_TIME_DAY"); //OFF Time Day
                    } else
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "WARNING_ON_OFF"); //OFF ON

                    //安全通知
                    if (cb_Safe_Notify.isChecked()) {
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "SAFE_NOTIFY"); //OFF ON
                        if (cb_Safe_Notify_alert.isChecked()) {
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "ALERT", "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
                        } else if (cb_Safe_Notify_email.isChecked())
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "EMAIL", "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
                        else if (cb_Safe_Notify_text.isChecked())
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "TEXT", "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
                        else
                            MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "WARNING_TIME_DAY"); //OFF Time Day
                    } else
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "SAFE_NOTIFY"); //OFF ON
                    Log.e(TAG, "ImageButton KeepParameter Success!");
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e(TAG, "ImageButton KeepParameter Fail!");
                }
                linearInfo.setVisibility(View.VISIBLE);
                linearInfoSet.setVisibility(View.INVISIBLE);
            }
        });


        final ImageButton imgBtnAlertSet = (ImageButton) findViewById(R.id.imgBtnAlertSet);
//        DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.mobile_main_information_ch_1);
        imgBtnAlertSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (linearInfo.getVisibility() == View.VISIBLE) {
                    linearInfo.setVisibility(View.INVISIBLE);
                    linearInfoSet.setVisibility(View.VISIBLE);
                } else {
                    linearInfo.setVisibility(View.VISIBLE);
                    linearInfoSet.setVisibility(View.INVISIBLE);
                    saveKeepParameter();
                }
            }
        });
        final ImageButton imgBtnAlert = (ImageButton) findViewById(R.id.imgBtnAlert);
//        DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.mobile_main_information_ch_1);
        imgBtnAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    ALARM_ON_OFF = MorSensorParameter.getKeepParameter(mUVViewActivity, "ALARM_ON_OFF"); //OFF ON
                } catch (IOException e) {
                    e.printStackTrace();
                    ALARM_ON_OFF = "OFF";
                }
                try {
                    if (!ALARM_ON_OFF.equals("ON")) { //開啟提醒
                        handler.postDelayed(runnableNotify, 1000);
//                        setNotify();
                        DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.test_off);
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "ALARM_ON_OFF"); //OFF ON
                    } else { //關閉提醒
                        cancelNotify();
                        DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.test_on);
                        MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "ALARM_ON_OFF"); //OFF ON
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        sp_protection_alert_index = (Spinner) findViewById(R.id.sp_protection_alert_index);
        //將可選内容與ArrayAdapter連接起來
        adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout, spinner_alert_index_list);
        //對應控件
        adapter.setDropDownViewResource(R.layout.spinner_layout);
        //將adapter 添加到spinner中
        sp_protection_alert_index.setAdapter(adapter);
        sp_protection_alert_index.setSelection(1, true);

        sp_protection_alert_index.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String spin_array[] = getResources().getStringArray(R.array.spinner_alert_index_list);
                String spin_array[] = spinner_alert_index_list;
                Toast.makeText(UVViewActivity.this, "你選的Index是" + spin_array[position], Toast.LENGTH_SHORT).show();
                protection_alert_index = Integer.parseInt(spin_array[position]);
                Log.i(TAG, "sp_protection_alert_index protection_alert_index:"+protection_alert_index);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sp_protection_alert_time = (Spinner) findViewById(R.id.sp_protection_alert_time);
        //將可選内容與ArrayAdapter連接起來
        adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout, spinner_alert_time_list);
        //對應控件
        adapter.setDropDownViewResource(R.layout.spinner_layout);
        //將adapter 添加到spinner中
        sp_protection_alert_time.setAdapter(adapter);
        sp_protection_alert_time.setSelection(3, true);
        sp_protection_alert_time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String spin_array[] = getResources().getStringArray(R.array.spinner_alert_time_list);
                String spin_array[] = spinner_alert_time_list;
                Toast.makeText(UVViewActivity.this, "你選的Time是" + spin_array[position], Toast.LENGTH_SHORT).show();
                protection_alert_time = Integer.parseInt(spin_array[position]);
                Log.i(TAG, "sp_protection_alert_time protection_alert_time:"+protection_alert_time);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        cb_protection_alert_index = (CheckBox) findViewById(R.id.cb_protection_alert_index);
        cb_protection_alert_time = (CheckBox) findViewById(R.id.cb_protection_alert_time);
        cb_warning = (CheckBox) findViewById(R.id.cb_warning);
        cb_warning_time = (CheckBox) findViewById(R.id.cb_warning_time);
        ed_hour = (EditText) findViewById(R.id.ed_hour);
        ed_minutes = (EditText) findViewById(R.id.ed_minutes);
        cb_warning_day = (CheckBox) findViewById(R.id.cb_warning_day);

        cb_Safe_Notify = (CheckBox) findViewById(R.id.cb_Safe_Notify);
        cb_Safe_Notify_alert = (CheckBox) findViewById(R.id.cb_Safe_Notify_alert);
        cb_Safe_Notify_email = (CheckBox) findViewById(R.id.cb_Safe_Notify_email);
        cb_Safe_Notify_text = (CheckBox) findViewById(R.id.cb_Safe_Notify_text);

        cb_protection_alert_index.setOnCheckedChangeListener(chklistener);
        cb_protection_alert_time.setOnCheckedChangeListener(chklistener);
        cb_warning.setOnCheckedChangeListener(chklistener);
        cb_warning_time.setOnCheckedChangeListener(chklistener);
        cb_warning_day.setOnCheckedChangeListener(chklistener);
        cb_Safe_Notify.setOnCheckedChangeListener(chklistener);
        cb_Safe_Notify_alert.setOnCheckedChangeListener(chklistener);
        cb_Safe_Notify_email.setOnCheckedChangeListener(chklistener);
        cb_Safe_Notify_text.setOnCheckedChangeListener(chklistener);


        /** 儲存結束
         protection_alert_index=Integer.parseInt(spinner_alert_index_list[sp_protection_alert_index.getSelectedItemPosition()]);
         protection_alert_time=Integer.parseInt(spinner_alert_time_list[sp_protection_alert_time.getSelectedItemPosition()]);
         warning_hour = Integer.parseInt(ed_hour.getText().toString());
         warning_minutes = Integer.parseInt(ed_minutes.getText().toString());


         */
        try {
            ALARM_ON_OFF = MorSensorParameter.getKeepParameter(mUVViewActivity, "ALARM_ON_OFF"); //OFF ON
//            if (ALARM_ON_OFF.equals("OFF"))
//                DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.mobile_main_alco_ch_red_1);
//            else
//                DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.mobile_main_alco_ch_red_1);

            PROTECTION_ALERT_INDEX_ON_OFF = MorSensorParameter.getKeepParameter(mUVViewActivity, "PROTECTION_ALERT_INDEX_ON_OFF"); //OFF ON
            if (PROTECTION_ALERT_INDEX_ON_OFF.equals("ON")) {
                cb_protection_alert_index.setChecked(true);
                DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.test_on);
            } else {
                cb_protection_alert_index.setChecked(false);
                DataTransform.setImageButtonDrawable(mContext, imgBtnAlert, R.drawable.test_off);
            }
            PROTECTION_ALERT_INDEX = MorSensorParameter.getKeepParameter(mUVViewActivity, "PROTECTION_ALERT_INDEX");
            sp_protection_alert_index.setSelection(searchIndexList(PROTECTION_ALERT_INDEX), true);

            PROTECTION_ALERT_TIME_ON_OFF = MorSensorParameter.getKeepParameter(mUVViewActivity, "PROTECTION_ALERT_TIME_ON_OFF"); //OFF ON
            if (PROTECTION_ALERT_TIME_ON_OFF.equals("ON"))
                cb_protection_alert_time.setChecked(true);
            else cb_protection_alert_time.setChecked(false);
            PROTECTION_ALERT_TIME = MorSensorParameter.getKeepParameter(mUVViewActivity, "PROTECTION_ALERT_TIME");
            sp_protection_alert_time.setSelection(searchTimeList(PROTECTION_ALERT_TIME), true);

            WARNING_ON_OFF = MorSensorParameter.getKeepParameter(mUVViewActivity, "WARNING_ON_OFF"); //OFF ON
            if (WARNING_ON_OFF.equals("ON"))
                cb_warning.setChecked(true);
            else cb_warning.setChecked(false);
            WARNING_TIME_DAY = MorSensorParameter.getKeepParameter(mUVViewActivity, "WARNING_TIME_DAY"); //OFF Time Day
            if (WARNING_TIME_DAY.equals("TIME")) {
                cb_warning_time.setChecked(true);
                cb_warning_day.setChecked(false);
            } else if (WARNING_TIME_DAY.equals("DAY")) {
                cb_warning_time.setChecked(false);
                cb_warning_day.setChecked(true);
            } else {
                cb_warning_time.setChecked(false);
                cb_warning_day.setChecked(false);
            }
            WARNING_HOUR = MorSensorParameter.getKeepParameter(mUVViewActivity, "WARNING_HOUR");
            WARNING_MINUTES = MorSensorParameter.getKeepParameter(mUVViewActivity, "WARNING_MINUTES");
            ed_hour.setText(WARNING_HOUR);
            ed_minutes.setText(WARNING_MINUTES);

            SAFE_NOTIFY = MorSensorParameter.getKeepParameter(mUVViewActivity, "SAFE_NOTIFY"); //OFF ON
            if (SAFE_NOTIFY.equals("ON"))
                cb_Safe_Notify.setChecked(true);
            else cb_Safe_Notify.setChecked(false);
            SAFE_NOTIFY_ALERT_EMAIL_TEXT = MorSensorParameter.getKeepParameter(mUVViewActivity, "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
            if (SAFE_NOTIFY_ALERT_EMAIL_TEXT.equals("ALERT"))
                cb_Safe_Notify_alert.setChecked(true);
        } catch (IOException e) {
            Log.e(TAG, "init KeepParameter");
            try {
                MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "ALARM_ON_OFF"); //OFF ON
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "PROTECTION_ALERT_INDEX_ON_OFF"); //OFF ON
                MorSensorParameter.setKeepParameter(mUVViewActivity, "" + protection_alert_index, "PROTECTION_ALERT_INDEX");
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "PROTECTION_ALERT_TIME_ON_OFF"); //OFF ON
                MorSensorParameter.setKeepParameter(mUVViewActivity, "" + protection_alert_time, "PROTECTION_ALERT_TIME");
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "WARNING_ON_OFF"); //OFF ON
                MorSensorParameter.setKeepParameter(mUVViewActivity, "DAY", "WARNING_TIME_DAY"); //OFF Time Day
                MorSensorParameter.setKeepParameter(mUVViewActivity, "" + warning_hour, "WARNING_HOUR");
                MorSensorParameter.setKeepParameter(mUVViewActivity, "" + warning_minutes, "WARNING_MINUTES");
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "SAFE_NOTIFY"); //OFF ON
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ALERT", "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
            } catch (IOException e2) {
                e.printStackTrace();
            }
        }
    }

    static String ALARM_ON_OFF, PROTECTION_ALERT_INDEX_ON_OFF,
            PROTECTION_ALERT_INDEX, PROTECTION_ALERT_TIME_ON_OFF, PROTECTION_ALERT_TIME,
            WARNING_ON_OFF, WARNING_TIME_DAY, WARNING_HOUR, WARNING_MINUTES,
            SAFE_NOTIFY, SAFE_NOTIFY_ALERT_EMAIL_TEXT;
    public static int protection_alert_index = 2, protection_alert_time = 30;
    static int warning_hour, warning_minutes;
    EditText ed_hour, ed_minutes;
    Spinner sp_protection_alert_index, sp_protection_alert_time;
    CheckBox cb_protection_alert_index, cb_protection_alert_time,
            cb_warning, cb_warning_time, cb_warning_day,
            cb_Safe_Notify, cb_Safe_Notify_alert, cb_Safe_Notify_email, cb_Safe_Notify_text;
    private CheckBox.OnCheckedChangeListener chklistener = new CheckBox.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView,
                                     boolean isChecked) {
            // TODO Auto-generated method stub
            int n = 0;
            String s1, s2, s3;

            //防曬警示設定
            if (cb_protection_alert_index.isChecked()) {
                sp_protection_alert_index.setEnabled(true);
            } else {
                sp_protection_alert_index.setEnabled(false);
            }
            //防護提醒設定
            if (cb_protection_alert_time.isChecked()) {
                sp_protection_alert_time.setEnabled(true);
            } else {
                sp_protection_alert_time.setEnabled(false);
            }

            //預警時間
            if (cb_warning.isChecked()) {
                cb_warning_time.setEnabled(true);
                cb_warning_day.setEnabled(true);
            } else {
                cb_warning_time.setEnabled(false);
                cb_warning_day.setEnabled(false);
            }

            if (cb_warning_time.isChecked()) {
                cb_warning_time.setChecked(true);
                cb_warning_day.setChecked(false);
            }
            if (cb_warning_day.isChecked()) {
                cb_warning_time.setChecked(false);
                cb_warning_day.setChecked(true);
            }

            //安全通知
            if (cb_Safe_Notify.isChecked()) {
                cb_Safe_Notify_alert.setEnabled(true);
//                cb_Safe_Notify_email.setEnabled(true);
//                cb_Safe_Notify_text.setEnabled(true);
            } else {
                cb_Safe_Notify_alert.setEnabled(false);
                cb_Safe_Notify_email.setEnabled(false);
                cb_Safe_Notify_text.setEnabled(false);
            }

            if (cb_Safe_Notify_alert.isChecked()) {

            } else {

            }
            if (cb_Safe_Notify_email.isChecked()) {

            } else {

            }
            if (cb_Safe_Notify_text.isChecked()) {

            } else {

            }
        }

    };

    int count = 0;
    AlarmManager alarmManager;
    PendingIntent pendingIntent;

    String title = "", ContentText = "", ContentInfo = "";

    private void setNotify() {
        count++;

//        Toast.makeText(mContext, "time:" + protection_alert_time + "  index:" + protection_alert_index, Toast.LENGTH_SHORT).show();
        //这里是定时的,这里设置的是每隔两秒打印一次时间=-=,自己改
//        int anHour = 1 * 1000;
//        long triggerAtTime = SystemClock.elapsedRealtime() + anHour;
//        Intent i = new Intent(this, AlarmReceiver.class);
//        i.putExtra("SENSOR_ID", MorSensorParameter.UVID);
//        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
//        pendingIntent = PendingIntent.getBroadcast(mContext, MorSensorParameter.UVID, i, 0);
//        alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtTime, protection_alert_time * 1000 * 60, pendingIntent);
        if (!(protection_alert_index < MorSensorParameter.uv_data))
            return;
        title = "MorSensor Mobile提醒";
        if (MorSensorParameter.uv_data <= 2)
            ContentText = "紫外線超出設定範圍 微量級；舒適安全範圍。";
        else if (MorSensorParameter.uv_data <= 5)
            ContentText = "紫外線超出範圍 一般級；需注意基本防曬。";
        else if (MorSensorParameter.uv_data <= 7)
            ContentText = "紫外線超出範圍 高量級；需加強防曬措施。";
        else if (MorSensorParameter.uv_data <= 10)
            ContentText = "紫外線超出範圍 過量級；應避免外出。";
        else if (MorSensorParameter.uv_data > 10)
            ContentText = "紫外線超出範圍 危險級。";

        Log.i(TAG, "AlarmReceiver:" + count);

        final int notifyID = 1; //通知的識別號碼
        // 取得NotificationManager物件
        NotificationManager manager = (NotificationManager)
                mContext.getSystemService(Context.NOTIFICATION_SERVICE);

        // 建立NotificationCompat.Builder物件
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(mContext);

        // 設定小圖示、大圖示、狀態列文字、時間、內容標題、內容訊息和內容額外資訊
        builder.setSmallIcon(R.drawable.uv_ciclogo)
                .setShowWhen(true)
                .setWhen(System.currentTimeMillis())
                .setContentTitle(title + count)//+count
                .setContentText(ContentText)
                .setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setSound(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.shop_chime));
        // 建立通知物件
        Notification notification = builder.build();

        // 使用CUSTOM_EFFECT_ID為編號發出通知
        assert manager != null;
        manager.notify(notifyID, notification);
        //// 清除BASIC_ID編號的通知
        //        manager.cancel(notifyID);
    }

    private void cancelNotify() {
        handler.removeCallbacks(runnableNotify);
//        Intent i = new Intent(this, AlarmReceiver.class);
//        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
//        pendingIntent = PendingIntent.getBroadcast(mContext, MorSensorParameter.UVID, i, 0);
//
//        alarmManager.cancel(pendingIntent);
//
//        pendingIntent = null;
//        alarmManager = null;
    }

    Handler handler = new Handler();
    Runnable runnableNotify = new Runnable() {
        @Override
        public void run() {
            setNotify();
            handler.postDelayed(runnableNotify, protection_alert_time * 1000);//protection_alert_time * 1000 * 60
        }
    };

    private int searchIndexList(String index) {
        Log.i(TAG, "searchIndexList:"+index);
        for (int i = 0; i < spinner_alert_index_list.length; i++) {
            if (index.equals(spinner_alert_index_list[i]))
                return i;
        }
        return 4;
    }

    private int searchTimeList(String time) {
        Log.i(TAG, "searchTimeList:"+time);
        for (int i = 0; i < spinner_alert_time_list.length; i++) {
            if (time.equals(spinner_alert_time_list[i]))
                return i;
        }
        return 4;
    }

    private void saveKeepParameter(){
        try {
            //防曬警示設定
            if (cb_protection_alert_index.isChecked()) {
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "PROTECTION_ALERT_INDEX_ON_OFF"); //OFF ON
                MorSensorParameter.setKeepParameter(mUVViewActivity, "" + protection_alert_index, "PROTECTION_ALERT_INDEX");
            } else
                MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "PROTECTION_ALERT_INDEX_ON_OFF"); //OFF ON

            //防護提醒設定
            if (cb_protection_alert_time.isChecked()) {
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "PROTECTION_ALERT_TIME_ON_OFF"); //OFF ON
                MorSensorParameter.setKeepParameter(mUVViewActivity, "" + protection_alert_time, "PROTECTION_ALERT_TIME");
            } else
                MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "PROTECTION_ALERT_TIME_ON_OFF"); //OFF ON

            Log.i(TAG, "imgbtnSave protection_alert_index:"+protection_alert_index+"    protection_alert_time:"+protection_alert_time);
            //預警時間
            if (cb_warning.isChecked()) {
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "WARNING_ON_OFF"); //OFF ON
                if (cb_warning_time.isChecked()) {
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "TIME", "WARNING_TIME_DAY"); //OFF Time Day
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "" + warning_hour, "WARNING_HOUR");
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "" + warning_minutes, "WARNING_MINUTES");
                } else if (cb_warning_day.isChecked())
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "DAY", "WARNING_TIME_DAY"); //OFF Time Day
                else
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "WARNING_TIME_DAY"); //OFF Time Day
            } else
                MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "WARNING_ON_OFF"); //OFF ON

            //安全通知
            if (cb_Safe_Notify.isChecked()) {
                MorSensorParameter.setKeepParameter(mUVViewActivity, "ON", "SAFE_NOTIFY"); //OFF ON
                if (cb_Safe_Notify_alert.isChecked()) {
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "ALERT", "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
                } else if (cb_Safe_Notify_email.isChecked())
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "EMAIL", "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
                else if (cb_Safe_Notify_text.isChecked())
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "TEXT", "SAFE_NOTIFY_ALERT_EMAIL_TEXT"); //OFF Alert Email Text
                else
                    MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "WARNING_TIME_DAY"); //OFF Time Day
            } else
                MorSensorParameter.setKeepParameter(mUVViewActivity, "OFF", "SAFE_NOTIFY"); //OFF ON
            Log.e(TAG, "ImageButton KeepParameter Success!");
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "ImageButton KeepParameter Fail!");
        }
    }
}

