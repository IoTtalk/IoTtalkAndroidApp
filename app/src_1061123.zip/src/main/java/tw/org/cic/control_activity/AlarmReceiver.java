package tw.org.cic.control_activity;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import tw.org.cic.dataManage.MorSensorParameter;
import tw.org.cic.morsensor_mobile.R;
import tw.org.cic.morsensor_mobile.UVViewActivity;

import static android.content.ContentValues.TAG;

/**
 * Created by wllai on 2017/11/17.
 */

public class AlarmReceiver extends BroadcastReceiver {
    static boolean Notify = false;
    Context mContext;
    String title = "", ContentText = "", ContentInfo = "";

    @Override
    public void onReceive(Context context, Intent intent) {
        //....do something

        mContext = context;
        sensorID = intent.getShortExtra("SENSOR_ID", (short) 0);


        switch (sensorID) {
            case MorSensorParameter.THID:

                break;
            case MorSensorParameter.UVID:
                if (UVViewActivity.protection_alert_index < MorSensorParameter.uv_data) {
                    title = "MorSensor Mobile提醒";
                    if (MorSensorParameter.uv_data <= 2)
                        ContentText = "紫外線超出設定範圍 微量級；舒適安全範圍。";
                    else if (MorSensorParameter.uv_data <= 5)
                        ContentText = "紫外線超出範圍 一般級；需注意基本防曬。";
                    else if (MorSensorParameter.uv_data <= 7)
                        ContentText = "紫外線超出範圍 高量級；需加強防曬措施。";
                    else if (MorSensorParameter.uv_data <= 10)
                        ContentText = "紫外線超出範圍 過量級；應避免外出。";
                    else if (MorSensorParameter.uv_data > 10)
                        ContentText = "紫外線超出範圍 危險級。";

                    setNotify(MorSensorParameter.UVID);
                }
                break;
            case MorSensorParameter.AlcoholID:

                break;

        }

//        Intent i = new Intent(context,LongRunningService.class);
//        context.startService(i);
    }

    static short sensorID;
    static int count = 0;

    private void setNotify(short sensorID) {
        count++;
        Log.i(TAG, "AlarmReceiver:" + count);

        final int notifyID = 1; //通知的識別號碼
        // 取得NotificationManager物件
        NotificationManager manager = (NotificationManager)
                mContext.getSystemService(Context.NOTIFICATION_SERVICE);

        // 建立NotificationCompat.Builder物件
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(mContext);


        // 設定小圖示、大圖示、狀態列文字、時間、內容標題、內容訊息和內容額外資訊
        builder.setSmallIcon(R.drawable.uv_ciclogo)
                .setWhen(System.currentTimeMillis())
                .setContentTitle(title)//+count
                .setContentText(ContentText)
                .setDefaults(Notification.DEFAULT_ALL);

        // 建立通知物件
        Notification notification = builder.build();
        // 使用CUSTOM_EFFECT_ID為編號發出通知
        manager.notify(notifyID, notification);
        //// 清除BASIC_ID編號的通知
        //        manager.cancel(notifyID);
    }


}