package tw.org.cic.control_activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import tw.org.cic.dataManage.DataTransform;
import tw.org.cic.morsensor_mobile.MainViewActivity;
import tw.org.cic.morsensor_mobile.R;


public class MainChoseActivity extends Activity {

    private static final String TAG = "MainChoseActivity";
    public static Activity mMainChoseActivity;
    private static Context context;
    public static String mDeviceAddress = "123";

    private boolean firstStatus = false;
    ImageView imgMain, imglayout;
    ImageButton imgbtn_reconnect;
    TextView tv_fw_ver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main_chose);

        mMainChoseActivity = this;
        context = this;

        tv_fw_ver = (TextView) this.findViewById(R.id.tv_fw_ver);
        imglayout = (ImageView) this.findViewById(R.id.imglayout);
        imgMain = (ImageView) this.findViewById(R.id.imgMain);
        imgbtn_reconnect = (ImageButton) this.findViewById(R.id.imgbtn_reconnect);

        DataTransform.setImageViewDrawable(mMainChoseActivity, imglayout, R.drawable.choice_words);
        DataTransform.setImageViewDrawable(mMainChoseActivity, imgMain, R.drawable.choice_bg);


        imgbtn_reconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(mMainChoseActivity, MainViewActivity.class);
                startActivityForResult(intent, 1);
//                ActivityForExtend.exitStatus = false;
//                Intent intent = new Intent();
//                intent.setClass(context, BLEListActivity.class);
//                startActivity(intent);
//                finish();
            }
        });



        if (!hasPermission()) {
            if (!needCheckPermission()) {
                //如果須要檢查權限，由於這個步驟要等待使用者確認，
                //所以不能立即執行儲存的動作，
                //必須在 onRequestPermissionsResult 回應中才執行
                Toast.makeText(mMainChoseActivity, "若不允許儲存權限，IRI Sensor將無法存取 !!", Toast.LENGTH_SHORT).show();
            }
        }

        Intent intent = new Intent();
        intent.setClass(this, MainViewActivity.class);
        startActivityForResult(intent, 1);


        Button btnTest = (Button) this.findViewById(R.id.btnTest);
        btnTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                try {
//                    DataInputStream dis=new DataInputStream(getAssets().open("index1.bin"));
//                    byte[] fileBytes=new byte[dis.available()];
//                    dis.read(fileBytes);
//                    dis.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (resultCode) {
            case RESULT_OK:
                Log.d(TAG, "onActivityResult  RESULT_OK");
                Toast.makeText(mMainChoseActivity, "MorSensor Mobile 連線成功 !", Toast.LENGTH_SHORT).show();
                byte[] rawdata = data.getByteArrayExtra("DATA");
                tv_fw_ver.setText("Firmware Ver. " + rawdata[0] + "." + rawdata[1] + "." + rawdata[2]);

//                Intent intent = new Intent();
//                intent.setClass(mMainChoseActivity, MainViewActivity.class);
//                startActivity(intent);

                break;
            case RESULT_CANCELED:
                Toast.makeText(mMainChoseActivity, "請連接 MorSensor Mobile !", Toast.LENGTH_SHORT).show();
                break;
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "+ ON DESTROY MainChoseActivity +");

        setContentView(R.layout.activity_null);
//        for (int i = ActivityForExtend.classList.length - 1; i >= 0; i--) {


//        finishAffinity();
    }



    /**
     * 確認是否要請求權限(API > 23)
     * API > 23 一律不用詢問權限
     */
    private boolean needCheckPermission() {
        //MarshMallow(API-23)之後要在 Runtime 詢問權限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] perms = {PERMISSION_WRITE_STORAGE};
            int permsRequestCode = 200;
            requestPermissions(perms, permsRequestCode);
            return true;
        }
        return false;
    }

    /**
     * 是否已經請求過該權限
     * API < 23 一律回傳 true
     */
    private boolean hasPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return (ActivityCompat.checkSelfPermission(this, PERMISSION_WRITE_STORAGE) == PackageManager.PERMISSION_GRANTED);
        }
        return true;
    }

    private final String PERMISSION_WRITE_STORAGE = "android.permission.WRITE_EXTERNAL_STORAGE";
}

