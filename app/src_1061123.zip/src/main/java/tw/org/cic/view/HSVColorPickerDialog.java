package tw.org.cic.view;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;


public class HSVColorPickerDialog extends AlertDialog {

	private static final int PADDING_DP = 5;
	
	private static final int CONTROL_SPACING_DP = 5;
	private static final int SELECTED_COLOR_HEIGHT_DP = 10;
	private static final int COLOR_INFORMATION_HEIGHT_DP = 50;
	private static final int SPINNER_HEIGHT_DP = 30;
	private static final int COLOR_GENERATED_HEIGHT = 60;
	
	private static final int BORDER_DP = 1;
	private static final int BORDER_COLOR = Color.BLACK;
	private static final int COLOR_WHEEL_SIZE = 600;
	
	private final OnColorSelectedListener listener;
	private static int selectedColor;
	private static ArrayList<TextView> tv_array;
	private static int color_generated[] = {0,0,0,0,0,0,0,0};
	
	
	public interface OnColorSelectedListener {
		/**
		 * @param color The color code selected, or null if no color. No color is only
		 * possible if {@link HSVColorPickerDialog#setNoColorButton(int) setNoColorButton()}
		 * has been called on the dialog before showing it
		 */
		public void colorSelected(Integer color);
	}
	
	public HSVColorPickerDialog(Context context, int initialColor, final OnColorSelectedListener listener) {
		super(context);
		this.selectedColor = initialColor;
		this.listener = listener;
		
		colorWheel = new HSVColorWheel( context );
		valueSlider = new HSVValueSlider( context );
		int padding = (int) (context.getResources().getDisplayMetrics().density * PADDING_DP);
		int borderSize = (int) (context.getResources().getDisplayMetrics().density * BORDER_DP);
		RelativeLayout layout = new RelativeLayout( context );
		
		RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams( COLOR_WHEEL_SIZE, COLOR_WHEEL_SIZE);
		lp.bottomMargin = (int) (context.getResources().getDisplayMetrics().density * CONTROL_SPACING_DP);
		colorWheel.setListener( new OnColorSelectedListener() {
			public void colorSelected(Integer color) {
				valueSlider.setColor( color, true );
			}
		} );
		colorWheel.setColor( initialColor );
		colorWheel.setId( 1 );
		lp.addRule( RelativeLayout.ALIGN_PARENT_LEFT);
		lp.addRule( RelativeLayout.ALIGN_PARENT_TOP);
		layout.addView( colorWheel, lp );
		
		int selectedColorHeight = (int) (context.getResources().getDisplayMetrics().density * SELECTED_COLOR_HEIGHT_DP);
		int colorInformationHeight = (int) (context.getResources().getDisplayMetrics().density * COLOR_INFORMATION_HEIGHT_DP);
		int spinnerrHeight = (int) (context.getResources().getDisplayMetrics().density * SPINNER_HEIGHT_DP);
		int colorGeneratedHeight = (int) (context.getResources().getDisplayMetrics().density * COLOR_GENERATED_HEIGHT);
		
		FrameLayout valueSliderBorder = new FrameLayout( context );
		valueSliderBorder.setBackgroundColor( BORDER_COLOR );
		valueSliderBorder.setPadding( borderSize, borderSize, borderSize, borderSize );
		valueSliderBorder.setId( 2 );
		lp = new RelativeLayout.LayoutParams( COLOR_WHEEL_SIZE, selectedColorHeight + 2 * borderSize );
		lp.bottomMargin = (int) (context.getResources().getDisplayMetrics().density * CONTROL_SPACING_DP);
		lp.addRule( RelativeLayout.BELOW, 1 );
		layout.addView( valueSliderBorder, lp );
		
		valueSlider.setColor( initialColor, false );
		valueSlider.setListener( new OnColorSelectedListener() {
			@Override
			public void colorSelected(Integer color) {
				selectedColor = color;
				selectedColorView.setBackgroundColor( color );
			}
		});
		valueSliderBorder.addView( valueSlider );
		
		FrameLayout selectedColorborder = new FrameLayout( context );
		selectedColorborder.setBackgroundColor( BORDER_COLOR );
		lp = new RelativeLayout.LayoutParams( COLOR_WHEEL_SIZE/3, colorInformationHeight + 2 * borderSize );
		selectedColorborder.setPadding( borderSize, borderSize, borderSize, borderSize );
		selectedColorborder.setId(3);
		lp.addRule( RelativeLayout.BELOW, 2 );
		layout.addView( selectedColorborder, lp );
		
	    TextView tv = new TextView(context);
	    
	    int color = initialColor & 0xFFFFFF;
	    int R = (color >> 16) & 0xFF;
	    int G = (color >> 8) & 0xFF;	    		
	    int B = color & 0xFF;
		String hexColor = String.format("R:0x%02X->%d\nG:0x%02X->%d\nB:0x%02X->%d\n", R,R,G,G,B,B);	    
	    
		tv.setText(hexColor);
		tv.setId(4);
		lp = new RelativeLayout.LayoutParams( COLOR_WHEEL_SIZE/2, colorInformationHeight + 2 * borderSize );
		selectedColorborder.setPadding( borderSize, borderSize, borderSize, borderSize );
		lp.addRule( RelativeLayout.BELOW, 2 );
		lp.addRule( RelativeLayout.RIGHT_OF, 3 );
		layout.addView( tv, lp );
		
		Spinner spinner = new Spinner(context);
		String[] list = {"同色系","相容色系","互補色系","雙互補色系"};
		ArrayAdapter<String> listAdapter;				

		listAdapter = new ArrayAdapter<String>(context,android.R.layout.simple_spinner_item, list);
		listAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(listAdapter);  
		spinner.setPrompt("下拉菜单");  
		spinner.setOnItemSelectedListener(new SpinnerOnItemSelectListener());
		
		lp = new RelativeLayout.LayoutParams( COLOR_WHEEL_SIZE, spinnerrHeight + 2 * borderSize );
		spinner.setPadding( borderSize, borderSize, borderSize, borderSize );
		spinner.setId(5);
		lp.addRule( RelativeLayout.RIGHT_OF, 1 );
		layout.addView( spinner, lp );

		tv_array = new ArrayList<TextView>();
		
		int previousID=5;		
		for(int i=0;i<4;i++)
		{
			TextView tv_tmp = new TextView(context);
			tv_tmp.setId(previousID + 1);
			lp = new RelativeLayout.LayoutParams( COLOR_WHEEL_SIZE, colorGeneratedHeight + 2 * borderSize );
			selectedColorborder.setPadding( borderSize, borderSize, borderSize, borderSize );
			lp.addRule( RelativeLayout.BELOW, previousID);
			lp.addRule( RelativeLayout.RIGHT_OF, 1 );
			layout.addView(tv_tmp, lp );
			previousID++;
			
			tv_array.add(tv_tmp);
		}
		
		Monochromatic();
		setColorInfo();
		
		selectedColorView = new View( context );
		selectedColorView.setBackgroundColor( selectedColor );
		selectedColorborder.addView( selectedColorView );
		
		setButton( BUTTON_NEGATIVE, context.getString( android.R.string.cancel ), clickListener );
		//setButton( BUTTON_POSITIVE, context.getString( android.R.string.ok ), clickListener );
		
		setView( layout, padding, padding, padding, padding );
	}
	
	private OnClickListener clickListener = new OnClickListener() {
		public void onClick(DialogInterface dialog, int which) {
			switch ( which ) {
			case BUTTON_NEGATIVE:
				dialog.dismiss();
				break;
			case BUTTON_NEUTRAL:
				dialog.dismiss();
				listener.colorSelected( -1 );
				break;
			case BUTTON_POSITIVE:
				listener.colorSelected( selectedColor );
				break;
			}
		}
	};

	private HSVColorWheel colorWheel;
	private HSVValueSlider valueSlider;

	private View selectedColorView;
	
	/**
	 * Adds a button to the dialog that allows a user to select "No color",
	 * which will call the listener's {@link OnColorSelectedListener#colorSelected(Integer) colorSelected(Integer)} callback
	 * with null as its parameter  
	 * @param res A string resource with the text to be used on this button
	 */
	public void setNoColorButton( int res ) {
		setButton( BUTTON_NEUTRAL, getContext().getString( res ), clickListener ); 
	}
	
	private static class SpinnerOnItemSelectListener implements OnItemSelectedListener{  
	    @Override  
	    public void onItemSelected(AdapterView<?> AdapterView, View view, int position,  
	            long arg3) {  
	        // TODO Auto-generated method stub  
	        String selected = AdapterView.getItemAtPosition(position).toString();

	        /*
	        if(selected == "同色搭配") 			Monochromatic();
	        else if(selected == "相容色搭配")		Analogous();
	        else if(selected == "互補搭配")		Complementary();
	        else if(selected == "雙互補搭配")		Triad();
	        */

	        switch(position)
	        {
	        	case 0: Monochromatic(); break;
	        	case 1: Analogous(); break;
	        	case 2: Complementary(); break;
	        	case 3: Triad(); break;
	        }
	        
	        setColorInfo();
	        System.out.println(selected);  
	    }  

	    @Override  
	    public void onNothingSelected(AdapterView<?> arg0) {  
	        // TODO Auto-generated method stub  
	        System.out.println("NothingSelected");  
	    }
	}
			
	private static class HSVColorWheel  extends View {
		
		private static final float SCALE = 1f;
		private static final float FADE_OUT_FRACTION = 0.03f;
		
		private static final int POINTER_LINE_WIDTH_DP = 2;
		private static final int POINTER_LENGTH_DP = 10;

		private final Context context;

		private OnColorSelectedListener listener;
		public HSVColorWheel(Context context, AttributeSet attrs, int defStyle) {
			super(context, attrs, defStyle);
			this.context = context;
			init();
		}

		public HSVColorWheel(Context context, AttributeSet attrs) {
			super(context, attrs);
			this.context = context;
			init();
		}

		public HSVColorWheel(Context context) {
			super(context);
			this.context = context;
			init();
		}
		
		private int scale;
		private int pointerLength;
		private int innerPadding;
		private Paint pointerPaint = new Paint();
		private void init() {
			float density = context.getResources().getDisplayMetrics().density;
			scale = (int) (density * SCALE);
			pointerLength = (int) (density * POINTER_LENGTH_DP );
			pointerPaint.setStrokeWidth(  (int) (density * POINTER_LINE_WIDTH_DP ) );
			innerPadding = pointerLength / 2;
		}
		
		public void setListener( OnColorSelectedListener listener ) {
			this.listener = listener;
		}
		
		float[] colorHsv = { 0f, 0f, 1f };
		public void setColor( int color ) {
			Color.colorToHSV(color, colorHsv);
			invalidate();
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			if ( bitmap != null ) {
				canvas.drawBitmap(bitmap, null, rect, null);
				float hueInPiInterval = colorHsv[0] / 180f * (float)Math.PI;
				
				selectedPoint.x = rect.left + (int) (-Math.cos( hueInPiInterval ) * colorHsv[1] * innerCircleRadius + fullCircleRadius);
				selectedPoint.y = rect.top + (int) (-Math.sin( hueInPiInterval ) * colorHsv[1] * innerCircleRadius + fullCircleRadius);
				
				canvas.drawLine( selectedPoint.x - pointerLength, selectedPoint.y, selectedPoint.x + pointerLength, selectedPoint.y, pointerPaint );
				canvas.drawLine( selectedPoint.x, selectedPoint.y - pointerLength, selectedPoint.x, selectedPoint.y + pointerLength, pointerPaint );
			}
		}
		
		private Rect rect;
		private Bitmap bitmap;

		private int[] pixels;
		private float innerCircleRadius;
		private float fullCircleRadius;
		
		private int scaledWidth;
		private int scaledHeight;
		private int[] scaledPixels;

		private float scaledInnerCircleRadius;
		private float scaledFullCircleRadius;
		private float scaledFadeOutSize;
		
		private Point selectedPoint = new Point();
		
		@Override
		protected void onSizeChanged(int w, int h, int oldw, int oldh) {
			super.onSizeChanged(w, h, oldw, oldh);
			
			rect = new Rect( innerPadding, innerPadding, w - innerPadding, h - innerPadding );
			bitmap = Bitmap.createBitmap( w - 2 * innerPadding, h - 2 * innerPadding, Config.ARGB_8888 );
			
			fullCircleRadius = Math.min( rect.width(), rect.height() ) / 2;
			innerCircleRadius = fullCircleRadius * ( 1 - FADE_OUT_FRACTION );
			
			scaledWidth = rect.width() / scale;
			scaledHeight = rect.height() / scale;
			scaledFullCircleRadius = Math.min( scaledWidth, scaledHeight ) / 2;
			scaledInnerCircleRadius = scaledFullCircleRadius * ( 1 - FADE_OUT_FRACTION );
			scaledFadeOutSize = scaledFullCircleRadius - scaledInnerCircleRadius;
			scaledPixels = new int[ scaledWidth * scaledHeight ];
			pixels = new int[ rect.width() * rect.height() ];
			
			createBitmap();
		}
		
		private void createBitmap() {
			int w = rect.width();
			int h = rect.height();
			
			float[] hsv = new float[] { 0f, 0f, 1f };
			int alpha = 255;
			
			int x = (int) -scaledFullCircleRadius, y = (int) -scaledFullCircleRadius;
			for ( int i = 0; i < scaledPixels.length; i++ ) {
				if ( i % scaledWidth == 0 ) {
					x = (int) -scaledFullCircleRadius;
					y++;
				} else {
					x++;
				}
				
				double centerDist = Math.sqrt( x*x + y*y );
				if ( centerDist <= scaledFullCircleRadius ) {
					hsv[ 0 ] = (float) (Math.atan2( y, x ) / Math.PI * 180f) + 180;
					hsv[ 1 ] = (float) (centerDist / scaledInnerCircleRadius);
					if ( centerDist <= scaledInnerCircleRadius ) {
						alpha = 255;
					} else {
						alpha = 255 - (int) ((centerDist - scaledInnerCircleRadius) / scaledFadeOutSize * 255);
					}
					scaledPixels[ i ] = Color.HSVToColor( alpha, hsv );
				} else {
					scaledPixels[ i ] = 0x00000000;
				}
			}
			
			int scaledX, scaledY;
			for( x = 0; x < w; x++ ) {
				scaledX = x / scale;
				if ( scaledX >= scaledWidth ) scaledX = scaledWidth - 1;
				for ( y = 0; y < h; y++ ) {
					scaledY = y / scale;
					if ( scaledY >= scaledHeight ) scaledY = scaledHeight - 1;
					pixels[ x * h + y ] = scaledPixels[ scaledX * scaledHeight + scaledY ];
				}
			}
			
			bitmap.setPixels( pixels, 0, w, 0, 0, w, h );
			
			invalidate();
		}

		@Override
		protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
			int maxWidth = MeasureSpec.getSize( widthMeasureSpec );
			int maxHeight = MeasureSpec.getSize( heightMeasureSpec );
			
			int width, height;
			/*
			 * Make the view quadratic, with height and width equal and as large as possible
			 */
			width = height = Math.min( maxWidth, maxHeight );
			
			setMeasuredDimension( width, height );
		}
		
		public int getColorForPoint( int x, int y, float[] hsv ) {
			x -= fullCircleRadius;
			y -= fullCircleRadius;
			double centerDist = Math.sqrt( x*x + y*y );
			hsv[ 0 ] = (float) (Math.atan2( y, x ) / Math.PI * 180f) + 180;
			hsv[ 1 ] = Math.max( 0f, Math.min( 1f, (float) (centerDist / innerCircleRadius) ) );
			return Color.HSVToColor( hsv );
		}

		@Override
		public boolean onTouchEvent(MotionEvent event) {
			/*
			int action = event.getActionMasked();
			switch ( action ) {
			case MotionEvent.ACTION_DOWN:
			case MotionEvent.ACTION_MOVE:
				if ( listener != null ) {
					listener.colorSelected( getColorForPoint( (int)event.getX(), (int)event.getY(), colorHsv ) );
				}
				invalidate();
				return true;
			}			
			return super.onTouchEvent(event);
			*/
			return true;
		}

	}
	
	private static class HSVValueSlider extends View {

		public HSVValueSlider(Context context, AttributeSet attrs, int defStyle) {
			super(context, attrs, defStyle);
		}

		public HSVValueSlider(Context context, AttributeSet attrs) {
			super(context, attrs);
		}

		public HSVValueSlider(Context context) {
			super(context);
		}
		
		private OnColorSelectedListener listener;
		public void setListener( OnColorSelectedListener listener ) {
			this.listener = listener;
		}
		
		float[] colorHsv = { 0f, 0f, 1f };
		public void setColor( int color, boolean keepValue ) {
			float oldValue = colorHsv[2];
			Color.colorToHSV(color, colorHsv);
			if ( keepValue ) {
				colorHsv[2] = oldValue;
			}
			if ( listener != null ) {
				listener.colorSelected( Color.HSVToColor( colorHsv ) );
			}
			
			createBitmap();
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			if ( bitmap != null ) {
				canvas.drawBitmap(bitmap, srcRect, dstRect, null);
			}
		}
		private Rect srcRect;
		private Rect dstRect;
		private Bitmap bitmap;
		private int[] pixels;
		
		@Override
		protected void onSizeChanged(int w, int h, int oldw, int oldh) {
			super.onSizeChanged(w, h, oldw, oldh);
			
			srcRect = new Rect( 0, 0, w, 1 );
			dstRect = new Rect( 0, 0, w, h );
			bitmap = Bitmap.createBitmap( w, 1, Config.ARGB_8888 );
			pixels = new int[ w ];
			
			createBitmap();
		}
		
		private void createBitmap() {
			if ( bitmap == null ) {
				return;
			}
			int w = getWidth();
			
			float[] hsv = new float[] { colorHsv[0], colorHsv[1], 1f };
			
			int selectedX = (int) (colorHsv[ 2 ] * w);
			
			float value = 0;
			float valueStep = 1f / w;
			for( int x = 0; x < w; x++ ) {
				value += valueStep;
				if ( x >= selectedX - 1 && x <= selectedX + 1 ) {
					int intVal = 0xFF - (int)( value * 0xFF );
					int color = intVal * 0x010101 + 0xFF000000;
					pixels[x] = color;
				} else {
					hsv[2] = value;
					pixels[x] = Color.HSVToColor( hsv );
				}
			}
			
			bitmap.setPixels( pixels, 0, w, 0, 0, w, 1 );
			
			invalidate();
		}

		@Override
		public boolean onTouchEvent(MotionEvent event) {
			int action = event.getActionMasked();
			switch ( action ) {
			case MotionEvent.ACTION_DOWN:
			case MotionEvent.ACTION_MOVE:
				/*
				int x = Math.max( 0, Math.min( bitmap.getWidth() - 1, (int)event.getX() ) );
				float value = x / (float)bitmap.getWidth();
				if ( colorHsv[2] != value ) {
					colorHsv[2] = value;
					if ( listener != null ) {
						listener.colorSelected( Color.HSVToColor( colorHsv ) );
					}
					createBitmap();
					invalidate();
				}
				*/
				return true;
			}
			return super.onTouchEvent(event);
		}
	}
	
	private static void Monochromatic()
	{
		int color = selectedColor & 0xFFFFFF;
	    int R = (color >> 16) & 0xFF;
	    int G = (color >> 8) & 0xFF;	    		
	    int B = color & 0xFF;

	    color_generated[0] = 0xFF000000 + color;
	    color_generated[1] = 0xFF000000 + rgbToColor(MonoC(R,1),MonoC(G,1),MonoC(B,1));
	    color_generated[2] = 0xFF000000 + rgbToColor(MonoC(R,2),MonoC(G,2),MonoC(B,2));
	    color_generated[3] = 0xFF000000 + rgbToColor(MonoC(R,3),MonoC(G,3),MonoC(B,3));
/*	    
	    color_generated[4] = 0xFF000000 + SecondC(color_generated[0]);
	    color_generated[5] = 0xFF000000 + SecondC(color_generated[1]);
	    color_generated[6] = 0xFF000000 + SecondC(color_generated[2]);
	    color_generated[7] = 0xFF000000 + SecondC(color_generated[3]);
*/
	    color_generated[4] = 0;
	    color_generated[5] = 0;
	    color_generated[6] = 0;
	    color_generated[7] = 0;
	}
	
	private static void Analogous()
	{
		int color = selectedColor & 0xFFFFFF;
		int HSL[] = {0,0,0};
		RGB2HSL(color,HSL);

		int H = HSL[0];
		
		color_generated[0] = 0xFF000000 + color;
		HSL[0] = FixHue(H+30);
		color_generated[1] = 0xFF000000 + HSL2RGB(HSL);
		HSL[0] = FixHue(H-30);
	    color_generated[2] = 0xFF000000 + HSL2RGB(HSL);
/*	    
	    color_generated[3] = 0xFF000000 + SecondC(color_generated[0]);
	    color_generated[4] = 0xFF000000 + SecondC(color_generated[1]);
	    color_generated[5] = 0xFF000000 + SecondC(color_generated[1]);
	    color_generated[6] = 0;
	    color_generated[7] = 0;
*/
	    color_generated[3] = 0;
	    color_generated[4] = 0;
	    color_generated[5] = 0;
	    color_generated[6] = 0;
	    color_generated[7] = 0;
	}
	
	private static void Complementary() 
	{
		int color = selectedColor & 0xFFFFFF;
	    int R = (color >> 16) & 0xFF;
	    int G = (color >> 8) & 0xFF;	    		
	    int B = color & 0xFF;
		
		int HSL[] = {0,0,0};
		RGB2HSL(color,HSL);

		int H = HSL[0];
		HSL[0] = FixHue(H+180);

		int color1 = HSL2RGB(HSL);
	    int R1 = (color1 >> 16) & 0xFF;
	    int G1 = (color1 >> 8) & 0xFF;	    		
	    int B1 = color1 & 0xFF;

	    color_generated[0] = 0xFF000000 + color;
	    color_generated[1] = 0xFF000000 + color1;	    
/*	    
	    color_generated[2] = 0xFF000000 + rgbToColor(MonoC(R,1),MonoC(G,1),MonoC(B,1));
	    color_generated[3] = 0xFF000000 + rgbToColor(MonoC(R1,1),MonoC(G1,1),MonoC(B1,1));
	    color_generated[4] = 0xFF000000 + SecondC(color_generated[0]);
	    color_generated[5] = 0xFF000000 + SecondC(color_generated[1]);
	    color_generated[6] = 0xFF000000 + SecondC(color_generated[2]);
	    color_generated[7] = 0xFF000000 + SecondC(color_generated[3]);
*/	    	    	    
	    color_generated[2] = 0;
	    color_generated[3] = 0;
	    color_generated[4] = 0;
	    color_generated[5] = 0;
	    color_generated[6] = 0;
	    color_generated[7] = 0;
	}
	
	private static void Triad() 
	{
		int color = selectedColor & 0xFFFFFF;
		int HSL[] = {0,0,0};
		RGB2HSL(color,HSL);

		int H1 = HSL[0] + 120;
		int H2 = HSL[0] - 120;
		
	    color_generated[0] = 0xFF000000 + color; 
	    HSL[0] = H1;	    
	    color_generated[1] = 0xFF000000 + HSL2RGB(HSL);	    
	    HSL[0] = H2;
	    color_generated[2] = 0xFF000000 + HSL2RGB(HSL);
	    
/*	    
	    color_generated[3] = 0xFF000000 + SecondC(color_generated[0]);		
	    color_generated[4] = 0xFF000000 + SecondC(color_generated[1]);
	    color_generated[5] = 0xFF000000 + SecondC(color_generated[2]);
	    color_generated[6] = 0;
	    color_generated[7] = 0;
*/
	    
	}
	
	
	
	private static void RGB2HSL(int color, int hsl[]) 
	{
	    int r = (color >> 16) & 0xFF;
	    int g = (color >> 8) & 0xFF;	    		
	    int b = color & 0xFF;
		
		float var_R = ( r / 255f );                    
		float var_G = ( g / 255f );
		float var_B = ( b / 255f );
		
		float var_Min;    //Min. value of RGB
		float var_Max;    //Max. value of RGB
		float del_Max;    //Delta RGB value
						 
		if (var_R > var_G) 
			{ var_Min = var_G; var_Max = var_R; }
		else 
			{ var_Min = var_R; var_Max = var_G; }

		if (var_B > var_Max) var_Max = var_B;
		if (var_B < var_Min) var_Min = var_B;

		del_Max = var_Max - var_Min; 
								 
		float H = 0, S, L;
		L = ( var_Max + var_Min ) / 2f;
	
		if ( del_Max == 0 ) { H = 0; S = 0; } // gray
		else {                                //Chroma
			if ( L < 0.5 ) 
				S = del_Max / ( var_Max + var_Min );
			else           
				S = del_Max / ( 2 - var_Max - var_Min );
	
			float del_R = ( ( ( var_Max - var_R ) / 6f ) + ( del_Max / 2f ) ) / del_Max;
			float del_G = ( ( ( var_Max - var_G ) / 6f ) + ( del_Max / 2f ) ) / del_Max;
			float del_B = ( ( ( var_Max - var_B ) / 6f ) + ( del_Max / 2f ) ) / del_Max;
	
			if ( var_R == var_Max ) 
				H = del_B - del_G;
			else if ( var_G == var_Max ) 
				H = ( 1 / 3f ) + del_R - del_B;
			else if ( var_B == var_Max ) 
				H = ( 2 / 3f ) + del_G - del_R;
			if ( H < 0 ) H += 1;
			if ( H > 1 ) H -= 1;
		}
		hsl[0] = (int)(360*H);
		hsl[1] = (int)(S*100);
		hsl[2] = (int)(L*100);
	}	

	private static int HSL2RGB(int hsl[])
	{
		int h = hsl[0];
		int s = hsl[1];
		int l = hsl[2];
		int r = 0;
		int g = 0;
		int b = 0;

		float L = ((float)l)/100;
		float S = ((float)s)/100;
		float H = ((float)h)/360;

		if(s == 0)
		{
			r = l;
			g = l;
			b = l;
		}
		else
		{
			float temp1 = 0;
			if(L < .50)
				temp1 = L*(1 + S);
			else
				temp1 = L + S - (L*S);

			float temp2 = 2*L - temp1;
			float temp3 = 0;
			
			int i;
			for(i = 0 ; i < 3 ; i++)
			{
				switch(i)
				{
					case 0: // red
						temp3 = H + .33333f;
						if(temp3 > 1)
						temp3 -= 1;
						r = H2VALUE(r,temp1,temp2,temp3);
						break;
					case 1: // green
						temp3 = H;
						g = H2VALUE(g,temp1,temp2,temp3);
						break;
					case 2: // blue
						temp3 = H - .33333f;
						if(temp3 < 0)
						temp3 += 1;
						b = H2VALUE(b,temp1,temp2,temp3);
						break;
					default:
						break;
				}
			}
		}
		r = (int)((((float)r)/100)*255);
		g = (int)((((float)g)/100)*255);
		b = (int)((((float)b)/100)*255);
		return r*0x10000 + g*0x100 + b;	
	}

	private static int H2VALUE(int c, float temp1, float temp2, float temp3)
	{
		if((temp3 * 6) < 1)
			c = (int)((temp2 + (temp1 - temp2)*6*temp3)*100);
		else if((temp3 * 2) < 1)
			c = (int)(temp1*100);
		else if((temp3 * 3) < 2)
			c = (int)((temp2 + (temp1 - temp2)*(.66666 - temp3)*6)*100);
		else
			c = (int)(temp2*100);
		return c;
	}

	
	
	private static int FixHue(int Hue) 
	{
		if(Hue<0) {
			return Hue+360;
		} else if(Hue>360) {
			return Hue-360;
		} else {
			return Hue;
		}
	}
	
	
	
	private static int MonoC(int c, int n)
	{	
		int diffC = c - 128;
		int diff = Math.abs(diffC);
		int par=0;
		int value = 0;
		int d=0;
	
		if(n==1)
		{
			par = 192;
			d = (int) Math.floor(0.5*diff);
		}else if(n==2)
		{
			par = 64;
			d = (int) Math.floor(0.5*diff);
		}else if(n==3)
		{
			par = 223;
			d = (int) Math.floor(0.25*diff);
		}
		
		if(diffC>=1) 
		{
			value = par + d;
		} else	if(diffC<0) 
		{
			value = par - d;
		} else {
			value = par;
		}
		
		return value;
	}
	
	private static int SecondC(int color) {

	    int R = (color >> 16) & 0xFF;
	    int G = (color >> 8) & 0xFF;	    		
	    int B = color & 0xFF;

		float par = 0.75f;

		R = (int) Math.floor(par*R);
		G = (int) Math.floor(par*G);
		B = (int) Math.floor(par*B);

		return rgbToColor(R,G,B);
	}
	
	private static int rgbToColor(int R, int G, int B)
	{
		return ((R<<16) + (G<<8) + B);
	}
	
	private static void setColorInfo()
	{
		for(int i=0; i<tv_array.size();i++)
		{
			int color = color_generated[i];
		    TextView tv = tv_array.get(i); 

			if(color == 0)
			{
				tv.setBackgroundColor(color);
				tv.setTextColor(color);

			}else
			{			
			    String hexColor = String.format("#%06X", (0xFFFFFF & color));
				tv.setBackgroundColor(color_generated[i]);
				tv.setTextColor(0xFFFFFFFF);
				tv.setText(hexColor);
			}
		}
	}
	
}