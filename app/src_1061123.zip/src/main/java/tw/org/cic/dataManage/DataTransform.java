package tw.org.cic.dataManage;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by 1404011 on 2015/5/22.
 */

public class DataTransform {
    private static final String TAG = "DataTransform";
    static float data[][] = new float[MorSensorParameter.clientCount][9];
    static short RawData[] = new short[20];

    public static float[] getData() {
        return data[0];
    }

    public static void TransformTempHumi(byte[] value) {

        float Temp_data = (float) ((value[2] & 0xFF) << 8 | (value[3] & 0xFF));
        float RH_data = (float) ((value[4] & 0xFF) << 8 | (value[5] & 0xFF));

        data[0][0] = (float) (Temp_data * 175.72 / 65536.0 - 46.85); //Temp
//        data[0][1] = RH_data + (25f - data[0][0]) * -1.5f; //RH
        data[0][1] = (float) (RH_data * 125.0 / 65536.0 - 6.0); //RH
        data[0][1] = data[0][1] + (25f - data[0][0]) * -1.5f; //RH
        if(data[0][1]>100)
            data[0][1] = 100f;

        Log.e(TAG, "Temp:" + data[0][0] + " Humi:" + data[0][1]);
    }

    public static void TransformUV(byte[] value) {

        float UV_data = ((float) (value[3 + 20] << 8 | (value[2 + 20] & 0xFF)) / 100f);

        if (UV_data < 1.8)
            data[0][2] = (float) (0.9208f * Math.pow(UV_data, 3) - 1.6399f * Math.pow(UV_data, 2f) + 1.2008f * UV_data - 0.054f);
        else if (UV_data < 4)
            data[0][2] = (float) (0.3389f * Math.pow(UV_data, 2f) + 0.7501f * UV_data - 0.2077f);
        else if (UV_data < 5) {
            float x = 0.49f * UV_data + 2.062f;
            data[0][2] = (float) (0.3389f * Math.pow(x, 2f) + 0.7501f * x - 0.2077f);
        } else data[0][2] = 5;

//        data[0][2] = (float) (UV_data / 100.0); //UV
        Log.e(TAG, "UV:" + data[0][2]);
    }

    static float a, b, a_p, ReadConter = 0;
    static DecimalFormat mDecimalFormat = new DecimalFormat("##.###");

    public static void TransformAlcohol(byte[] value) {
        ReadConter++;

        float Alc_out;
        Alc_out = (float) ((value[2 + 40] << 8 | (value[3 + 40] & 0xFF)) / 4096.0 * 3.3);
        data[0][3] = 1.004f * (float) Math.pow(Alc_out, 3) - 1.8891f * (float) Math.pow(Alc_out, 2) + 1.3245f * Alc_out - 0.2571f;
        data[0][4] = Alc_out;
        Log.e(TAG, "Alc_out:" + Alc_out + " data[0][3]:" + data[0][3]);
//        if (data[0][3] < 0)
//            data[0][3] = 0;
    }


    private static final int CONTENT_SIZE = 18;

    public static short[] checkLengthASCII(int check, String data, byte cmd) {
        short[] RawCommand = new short[20];
        byte[] b = data.getBytes(Charset.forName("UTF-8"));
        if (check == 1 && b.length <= CONTENT_SIZE) { //小於18
            RawCommand[0] = cmd;
            RawCommand[1] = 0x01;
            for (int i = 0; i < b.length; i++)
                RawCommand[i + 2] = b[i];
            return RawCommand;
        } else if (check == 1) { //大於18
            RawCommand[0] = cmd;
            RawCommand[1] = 0x01;
            for (int i = 0; i < CONTENT_SIZE; i++)
                RawCommand[i + 2] = b[i];
            return RawCommand;
        } else if (check == 2) { //大於18
            RawCommand[0] = cmd;
            RawCommand[1] = 0x02;
            for (int i = 0; i < b.length - CONTENT_SIZE; i++)
                RawCommand[i + 2] = b[i + CONTENT_SIZE];
            return RawCommand;
        } else {
            return RawCommand;
        }
    }

    // Byte[] to HexString
    public static String bytesToHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);

        for (byte byteChar : bytes) {
            sb.append(String.format("%02X", byteChar));
        }
        return sb.toString();
    }

    // HexString to Byte[]
    public static byte[] hexToBytes(String hexString) {
        char[] hex = hexString.toCharArray();
        //轉rawData長度減半
        int length = hex.length / 2;
        byte[] rawData = new byte[length];
        for (int i = 0; i < length; i++) {
            //先將hex資料轉10進位數值
            int high = Character.digit(hex[i * 2], 16);
            int low = Character.digit(hex[i * 2 + 1], 16);
            //將第一個值的二進位值左平移4位,ex: 00001000 => 10000000 (8=>128)
            //然後與第二個值的二進位值作聯集ex: 10000000 | 00001100 => 10001100 (137)
            int value = (high << 4) | low;
            //與FFFFFFFF作補集
            if (value > 127)
                value -= 256;
            //最後轉回byte就OK
            rawData[i] = (byte) value;
        }
        return rawData;
    }

    public static int convertTwoBytesToIntUnsigned(byte b1, byte b2)      // unsigned
    {
        return (b1 & 0xFF) << 8 | (b2 & 0xFF);
    }

    public static short convertTwoBytesToShortUnsigned(byte b1, byte b2)      // unsigned
    {
        return (short) ((b1 & 0xFF) << 8 | (b2 & 0xFF));
    }

    static List<Bitmap> bitmapList = new ArrayList<>();

    public static void setImageViewDrawable(Context context, ImageView img, int drawable) {
        InputStream is = context.getResources().openRawResource(drawable);
        BitmapFactory.Options options = new BitmapFactory.Options();
//        try {
//            options.getClass().getField("inNativeAlloc").setBoolean(options, true);
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (NoSuchFieldException e) {
//            e.printStackTrace();
//        }
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        options.inPurgeable = true;
        options.inInputShareable = true;
        img.setScaleType(ImageView.ScaleType.FIT_XY);
        Bitmap bitmap = BitmapFactory.decodeStream(is, null, options);
        img.setImageBitmap(bitmap);

//        if (bitmap != null && !bitmap.isRecycled()) {
//            bitmap.recycle();   //回收圖片所占的記憶體
//            Log.e(TAG, "recycleBimap:" + bitmap);
//            bitmap = null;
//        }
//        if (context != MainChoseActivity.mMainChoseActivity && bitmapList.size() == 0) {
//            recycleStatus = false;
//            bitmapList.add(BitmapFactory.decodeStream(is, null, options));
//            img.setImageBitmap(bitmapList.get(bitmapList.size() - 1));
//        } else {
//            Bitmap bitmap = BitmapFactory.decodeStream(is, null, options);
//            img.setImageBitmap(bitmap);
//        }
    }

    public static void setImageButtonDrawable(Context context, ImageButton imgBtn, int drawable) {
        recycleStatus = false;
        InputStream is = context.getResources().openRawResource(drawable);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        options.inPurgeable = true;
        options.inInputShareable = true;
        Bitmap bitmap = BitmapFactory.decodeStream(is, null, options);
        imgBtn.setImageBitmap(bitmap);
//        bitmapList.add(BitmapFactory.decodeStream(is, null, options));
//        imgBtn.setImageBitmap(bitmapList.get(bitmapList.size() - 1));
    }

    public static void setFrameLayout(Context context, FrameLayout layout, int drawable) {
        recycleStatus = false;
        InputStream is = context.getResources().openRawResource(drawable);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeStream(is, null, options);
        Drawable dr = new BitmapDrawable(bitmap);
//        bitmapList.add(BitmapFactory.decodeStream(is, null, options));
//        Drawable dr = new BitmapDrawable(bitmapList.get(bitmapList.size() - 1));
        layout.setBackgroundDrawable(dr);
    }

    public static void setRelativeLayout(Context context, RelativeLayout layout, int drawable) {
        recycleStatus = false;
        InputStream is = context.getResources().openRawResource(drawable);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeStream(is, null, options);
        Drawable dr = new BitmapDrawable(bitmap);
//        bitmapList.add(BitmapFactory.decodeStream(is, null, options));
//        Drawable dr = new BitmapDrawable(bitmapList.get(bitmapList.size() - 1));
        layout.setBackgroundDrawable(dr);
    }

    public static void setLinearLayout(Context context, LinearLayout layout, int drawable) {
        recycleStatus = false;
        InputStream is = context.getResources().openRawResource(drawable);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeStream(is, null, options);
        Drawable dr = new BitmapDrawable(bitmap);
//        bitmapList.add(BitmapFactory.decodeStream(is, null, options));
//        Drawable dr = new BitmapDrawable(bitmapList.get(bitmapList.size() - 1));
        layout.setBackgroundDrawable(dr);
    }

    public static boolean recycleStatus = false;

    public static void recycleBitmap() {
        recycleStatus = true;
        for (int i = 0; i < bitmapList.size(); i++) {
            if (!bitmapList.get(i).isRecycled()) {
                bitmapList.get(i).recycle();   //回收圖片所占的記憶體
                Log.e(TAG, "recycleBimap bitmapList.size():" + bitmapList.size() + " i:" + i);
            }
        }
        bitmapList.clear();
        bitmapList = null;
        bitmapList = new ArrayList<>();
        System.gc(); //提醒系統及時回收
        Log.i(TAG, "Recycle Bitmap.");
    }

//    public static void recycleView(View view) {
//        Log.e(TAG, "view.getDrawingCache():" + view.getDrawingCache());
//        if (!view.getDrawingCache().isRecycled()) {
//            view.getDrawingCache().recycle();   //回收圖片所占的記憶體
////                Log.e(TAG, "recycleBimap bitmapList.size():" + bitmapList.size() + " i:" + i);
//        }
//        System.gc(); //提醒系統及時回收
//    }


}
