package tw.org.cic.control_activity;

import android.app.Activity;
import android.app.NotificationManager;
import android.os.Bundle;

import tw.org.cic.morsensor_mobile.R;

public class NotificationActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        //打开NotificationActivity这个Activity后把通知给关掉
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.cancel(1);
    }

}