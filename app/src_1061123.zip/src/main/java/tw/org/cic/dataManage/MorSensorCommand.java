package tw.org.cic.dataManage;


import android.util.Log;

public class MorSensorCommand {
    protected static final String TAG = "MorSensorCommands";

    public static final int MAX_COMMAND_LENGTH = 20;

    /* output commands */
    public static final int OUT_NULL_COMMAND = 1; //0x01
    public static final int OUT_GET_ALL_SENSOR_ID = 2; //0x02 Internal use
    public static final int OUT_GET_ALL_LONG_SENSOR_ID = 3; //0x03 Internal use
    public static final int OUT_GET_MORSENSOR_VERSION = 4; //0x04 Internal use
    public static final int OUT_GET_FIRMWARE_VERSION = 5; //0x05 Internal use
    public static final int OUT_GET_SENSOR_PARAMETER = 6; //0x06
    public static final int OUT_GET_LONG_SENSOR_PARAMETER = 7; //0x07
    //Second level commands for 0x06 and 0x07
    public static final int OUT_OUT_GET_VERSION = 1; //0x01 Internal use
    public static final int OUT_OUT_GET_REGISTER_CONTENT = 2; //0x02
    public static final int OUT_OUT_GET_TRANSMIT_MODE = 3; //0x03 Internal use
    public static final int OUT_SET_SENSOR_PARAMETER = 8; //0x08
    public static final int OUT_SET_LONG_SENSOR_PARAMETER = 9; //0x09
    //Second level commands for 0x08 and 0x09
    public static final int OUT_OUT_SET_REGISTER_CONTENT = 1; //0x01
    public static final int OUT_OUT_SET_TRANSMIT_MODE = 2; //0x02
    public static final int OUT_OUT_START_TRANSMIT = 3; //0x03
    public static final int OUT_OUT_STOP_TRANSMIT = 4; //0x04
    public static final int OUT_SET_NONSENSOR_DEVICE = 10; //0x0A
    //Second level commands for 0x02
    public static final int OUT_OUT_MODE_TRANSMIT_ONCE = 0; //0x00
    public static final int OUT_OUT_MODE_TRANSMIT_CONTINUOUS = 1; //0x01
    //Second level commands for 0x0A
    public static final int OUT_OUT_SET_LED = 1; //0x01
    //Third level commands for 0x0A 0x01
    public static final int OUT_OUT_OUT_LED2 = 2; //0x02
    //Third level commands for 0x0A 0x01
    public static final int OUT_OUT_OUT_OUT_ON = 1; //0x01
    public static final int OUT_OUT_OUT_OUT_OFF = 2; //0x02
    public static final int OUT_OUT_OUT_INVERSE = 3; //0x03
    public static final int OUT_OUT_SET_BUZZER = 2; //0x02


    /* sensor data and status report */
    public static final int IN_NULL_COMMAND_REPORT = 1; //0x01
    public static final int IN_SENSOR_DISCOVERED = 2; //0x02 Internal use
    public static final int IN_LONG_SENSOR_DISCOVERED = 3; //0x03 Internal use. Temporally not implement
    public static final int IN_MORSENSORVERSION_REPORT = 4; //0x04 Internal use
    public static final int IN_FIRMWAREVERSION_REPORT = 5; //0x05 Internal use
    public static final int IN_SENSOR_PARAMETER_REPORT = 6; //0x06. Temporally not implement
    public static final int IN_LONG_SENSOR_PARAMETER_REPORT = 7; //0x07. Temporally not implement
    //Second level commands for 0x06 and 0x07
    public static final int IN_IN_VERSION_REPORT = 1; //0x01
    public static final int IN_IN_REGISTER_CONTENT_REPORT = 2; //0x02
    public static final int IN_IN_TRANSMIT_MODE_REPORT = 3; //0x03
    public static final int IN_SENSOR_PARAMETER_SET = 8; //0x08. Temporally not implement
    public static final int IN_LONG_SENSOR_PARAMETER_SET = 9; //0x09. Temporally not implement
    public static final int IN_NONSENSOR_DEVICE_SET = 10; //0x0A. Temporally not implement
    public static final int IN_DISCONNECTED = 11; //0x0B

    public static final int IN_SENSOR_FILE_RECEIVED =  249; //0xF9. Temporally not implement
    public static final int IN_LONG_SENSOR_FILE_RECEIVED = 250; //0xFA. Temporally not implement
    public static final int IN_SENSOR_DATA_RECEIVED =  251; //0xFB
    public static final int IN_LONG_SENSOR_DATA_RECEIVED = 252; //0xFC. Temporally not implement
    public static final int IN_STATUS_REPORT = 253; //0xFD. Temporally not implement
    //Second level commands for 0xFD
    //...
    public static final int IN_ERROR_REPORT = 254; //0xFE. Temporally not implement
    //Second level commands for 0xFE
    //...

    public static short[] command={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


    //Encode
    public static short[] GetSensorID(){
        Log.i(TAG, "o0x02:Send a GetAllSensorID command!");
        command[0] = OUT_GET_ALL_SENSOR_ID;
        return command;
    }

    public static short[] GetMorSensorVersion(){
        Log.i(TAG, "o0x04:Send a GetMorSensorVersion command!");
        command[0] = OUT_GET_MORSENSOR_VERSION;
        return command;
    }

    public static short[] GetOldFirmwareVersion(){
        Log.i(TAG, "o0x05:Send a GetFirmwareVersion command!");
        command[0] = OUT_GET_FIRMWARE_VERSION;
        return command;
    }

    public static short[] GetSensorParameter(short SensorID){
        Log.i(TAG, "o0x06 0x03:Get Sensor SetSensorParameter!");
        command[0] = OUT_GET_SENSOR_PARAMETER;
        command[1] = OUT_OUT_GET_TRANSMIT_MODE;
        command[2] = SensorID;
        return command;
    }

    public static short[] SetSensorParameterRegister(short SensorID){

        return command;
    }

    public static short[] SetSensorParameterOnce(short SensorID){
        Log.i(TAG, "o0x08 0x02:Send a SetSensorParameter - SetTransmitMode One mode command!");
        command[0] = OUT_SET_SENSOR_PARAMETER;
        command[1] = OUT_OUT_SET_TRANSMIT_MODE;
        command[2] = SensorID;
        command[3] = OUT_OUT_MODE_TRANSMIT_ONCE;
        return command;
    }

    public static short[] SetSensorParameterContinuous(short SensorID){
        Log.i(TAG, "o0x08 0x02:Send a SetSensorParameter - SetTransmitMode Continuous mode command!");
        command[0] = OUT_SET_SENSOR_PARAMETER;
        command[1] = OUT_OUT_SET_TRANSMIT_MODE;
        command[2] = SensorID;
        command[3] = OUT_OUT_MODE_TRANSMIT_CONTINUOUS;
        return command;
    }

    public static short[] SetColorSensorLEDOn(){
        command[0] = OUT_SET_NONSENSOR_DEVICE; //0x0A
        command[1] = OUT_OUT_SET_LED;//0x01
        command[2] = OUT_OUT_OUT_LED2;//0x02
        command[3] = OUT_OUT_OUT_OUT_ON;//0x01
        return command;
    }

    public static short[] SetColorSensorLEDOff(){
        command[0] = OUT_SET_NONSENSOR_DEVICE; //0x0A
        command[1] = OUT_OUT_SET_LED;//0x01
        command[2] = OUT_OUT_OUT_LED2;//0x02
        command[3] = OUT_OUT_OUT_OUT_OFF;//0x02
        return command;
    }

    public static short[] SetSpO2SensorLEDOff(short SensorID){
        command[0] = OUT_SET_SENSOR_PARAMETER; //0x08
        command[1] = OUT_OUT_SET_REGISTER_CONTENT;//0x01
        command[2] = SensorID;
        command[3] = 0;//0x00
        command[4] = 34;//0x22
        command[5] = 3;//0x03
        command[6] = 1;//0x01
        command[7] = 9;//0x09
        command[8] = 9;//0x09
        return command;
    }

    public static short[] SetSensorParameterStop(short SensorID){
        //Log.i(TAG, "o0x08 0x02:Send a SetSensorParameter - SetTransmitMode Stop mode command!");
        command[0] = OUT_SET_SENSOR_PARAMETER;
        command[1] = OUT_OUT_STOP_TRANSMIT;
        command[2] = SensorID;
        return command;
    }

    public static short[] Comm_Test(short SensorID){
        Log.i(TAG, "o0x08 0x02:Send a SetSensorParameter - SetTransmitMode Continuous mode command!");
        command[0] = OUT_SET_SENSOR_PARAMETER;
        command[1] = OUT_OUT_SET_TRANSMIT_MODE;
        command[2] = SensorID;
        command[3] = OUT_OUT_MODE_TRANSMIT_CONTINUOUS;
        return command;
    }

}
