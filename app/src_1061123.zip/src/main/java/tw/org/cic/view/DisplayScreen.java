package tw.org.cic.view;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;

/**
 * Created by 1404011 on 2015/5/27.
 */
public class DisplayScreen {
    private final static int WidthRaw = 1080, HeightRaw = 1920;
    public static int vWidth, vHeight;
    public static float time, DensityScale;

    //1:1.46146 (Note3:Tablet)
    public static void DisplayScreen(Activity mActivity){
        // 取得螢幕解析度
        DisplayMetrics dm = new DisplayMetrics();
        mActivity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        DensityScale = 3 / mActivity.getResources().getDisplayMetrics().density;

        vWidth = dm.widthPixels;
        vHeight = dm.heightPixels;
        if(vWidth / WidthRaw > vHeight / HeightRaw)
            time = (float)vHeight / (float)HeightRaw;
        else
            time = (float)vWidth / (float)WidthRaw;

        Log.e("DisplayScreen", "Screen Width:"+vWidth+" Height:"+vHeight + " time:"+time + " Density:"+DensityScale);
    }

    public static void mImageViewSize(ImageView imgid, int width, int hight) {
        // TODO 自動產生的方法 Stub
        LayoutParams params = imgid.getLayoutParams();  //需import android.view.ViewGroup.LayoutParams;
        params.width = (int)(width * time);
        params.height = (int)(hight * time);
        Log.e("DisplayScreen", "mImageViewSize Width:"+params.width+" Height:"+params.height+ " time:"+time);
        imgid.setLayoutParams(params);
    }

    public static ImageView mRawImageSize(ImageView imgid) {
        // TODO 自動產生的方法 Stub
        int w = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        imgid.measure(w, h);
        return imgid;
//        int height =imgid.getMeasuredHeight();
//        int width =imgid.getMeasuredWidth();
    }

    public static void mMarginLayout(ImageView imgid) {
        // TODO 自動產生的方法 Stub
        ViewGroup.MarginLayoutParams lpimgFooter = (ViewGroup.MarginLayoutParams) imgid.getLayoutParams();
        lpimgFooter.bottomMargin = 118;//Tablet
//        lpimgFooter.bottomMargin = 179;//Note3
        lpimgFooter.rightMargin = 18;//Tablet
//        lpimgFooter.rightMargin = 27;//Note3
        imgid.setLayoutParams(lpimgFooter);

    }

//    // The gesture threshold expressed in dp
//    private static final float GESTURE_THRESHOLD_DP = 16.0f;
//    public static void mDensityScale(Activity mActivity) {
//        // Get the screen's density scale
//        DensityScale = mActivity.getResources().getDisplayMetrics().density;
//        // Convert the dps to pixels, based on density scale
//        mGestureThreshold = (int) (GESTURE_THRESHOLD_DP * DensityScale + 0.5f);
//    }

}
