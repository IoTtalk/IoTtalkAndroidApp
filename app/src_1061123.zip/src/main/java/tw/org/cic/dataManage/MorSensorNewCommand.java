package tw.org.cic.dataManage;


import android.util.Log;

public class MorSensorNewCommand {
    protected static final String TAG = "MorSensorNewCommands";
    public static short[] command={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

    //Encode
    public static short[] GetEcho(){
        Log.i(TAG, "o0x01:Echo command!");
        command[0] = MorSensorParameter.OUT_ECHO;
        return command;
    }

    public static short[] GetSensorID(){
        Log.i(TAG, "o0x02:Send a GetAllSensorID command!");
        command[0] = MorSensorParameter.OUT_SENSOR_LIST;
        return command;
    }

    public static short[] GetMorSensorVersion(){
        Log.i(TAG, "o0x03:Send a GetMorSensorVersion command!");
        command[0] = MorSensorParameter.OUT_MORSENSOR_VERSION;
        return command;
    }

    public static short[] GetFirmwareVersion(){
        Log.i(TAG, "o0x04:Send a GetFirmwareVersion command!");
        command[0] = MorSensorParameter.OUT_FIRMWARE_VERSION;
        return command;
    }

    public static short[] GetLostSensorFileData(short SensorID, short lost1, short lost2){
        Log.i(TAG, "o0x13 SensorID:Send a GetLostSensorData - GetRegisterContent command!");
        command[0] = MorSensorParameter.OUT_LOST_SENSOR_DATA;
        command[1] = SensorID;
        command[2] = lost1;
        command[3] = lost2;
        return command;
    }

    public static short[] SetTransmissionSingle(short SensorID){
        Log.i(TAG, "o0x21 0x00:Send a SetTransmission - SetTransmitMode Single mode command!");
        command[0] = MorSensorParameter.OUT_SET_TRANSMISSION_MODE;
        command[1] = SensorID;
        command[2] = MorSensorParameter.OUT_OUT_SET_TRANSMISSION_SINGLE;
        return command;
    }

    public static short[] SetTransmissionContinuous(short SensorID){
        Log.i(TAG, "o0x21 0x01:Send a SetTransmission - SetTransmitMode Continuous mode command!");
        command[0] = MorSensorParameter.OUT_SET_TRANSMISSION_MODE;
        command[1] = SensorID;
        command[2] = MorSensorParameter.OUT_OUT_SET_TRANSMISSION_CONTINUOUS;
        return command;
    }

    public static short[] SetStopTransmission(short SensorID){
        Log.i(TAG, "o0x22:Send a SetStopTransmission - SetTransmitMode Stop mode command!");
        command[0] = MorSensorParameter.OUT_STOP_TRANSMISSION;
        command[1] = SensorID;
        return command;
    }

    public static short[] SetSpO2SensorLEDOn(short SensorID){
        Log.i(TAG, "o0x23:Send a SetRegisterContent - SpO2 LED Open command!");
        command[0] = MorSensorParameter.OUT_SET_REGISTER_CONTENT; //0x23
        command[1] = MorSensorParameter.SpO2ID;
        command[2] = 0;  //0x00
        command[3] = 34; //0x22
        command[4] = 3;  //0x03
        command[5] = 1;  //0x01
        command[6] = 9;  //0x09
        command[7] = 9;  //0x09
        return command;
    }

    public static short[] StopWIFITransmission(short SensorID){
        Log.i(TAG, "o0x24:Send a SetRegisterContent - Stop WIFI Transmission!");
        command[0] = MorSensorParameter.OUT_STOP_WIFI_TRANSMISSION; //0x23
        command[1] = SensorID;
        return command;
    }

    public static short[] SetLEDOff(short LEDID){
        Log.i(TAG, "o0x31 0xID 0x00:Modify LED State - Set LED Off command!");
        command[0] = MorSensorParameter.OUT_MODIFY_LED_STATE;
        command[1] = LEDID;
        command[2] = MorSensorParameter.OUT_OUT_OUT_MODIFY_LED_OFF;
        return command;
    }

    public static short[] SetLEDOn(short LEDID){
        Log.i(TAG, "o0x31 0xID 0x01:Modify LED State - Set LED On command!");
        command[0] = MorSensorParameter.OUT_MODIFY_LED_STATE;
        command[1] = LEDID;
        command[2] = MorSensorParameter.OUT_OUT_OUT_MODIFY_LED_ON;
        return command;
    }

    public static short[] SetWIFIServerIP(byte ip1, byte ip2, byte ip3, byte ip4, byte port1, byte port2){
        Log.i(TAG, "o0x43 :Set WIFI Server IP!");
        command[0] = MorSensorParameter.OUT_SET_WIFI_SERVER_IP;
        command[1] = ip1;
        command[2] = ip2;
        command[3] = ip3;
        command[4] = ip4;
        command[5] = port1;
        command[6] = port2;
        return command;
    }

    public static short[] SetTCPConnection(boolean status){
        Log.i(TAG, "o0x44 :Set TCP Connection! " + status);
        command[0] = MorSensorParameter.OUT_SET_TCP_CONNECTION;
        if(status) command[1] = 1;
        else command[1] = 0;
        return command;
    }
    public static short[] GetFileDataSize(short SensorID){
        Log.i(TAG, "o0xF1 "+SensorID+":Get File Data Size command!");
        command[0] = MorSensorParameter.OUT_BLE_FILE_DATA_SIZE;
        command[1] = SensorID;
        return command;
    }

    public static short[] GetFileData(short SensorID){
        Log.i(TAG, "o0xF2 "+SensorID+":Get File Data command!");
        command[0] = MorSensorParameter.OUT_BLE_FILE_DATA;
        command[1] = SensorID;
        return command;
    }

    public static short[] GetSensorData(short SensorID){
        Log.i(TAG, "o0xF3 "+SensorID+":Get Sensor Data command!");
        command[0] = MorSensorParameter.OUT_BLE_SENSOR_DATA;
        command[1] = SensorID;
        return command;
    }


    public static short[] CheckPowerStatus(){
        Log.i(TAG, "o0x12:Get Register Content - Check Power Status command!");
        command[0] = MorSensorParameter.OUT_REGISTER_CONTENT; //0x12
        command[1] = 0xAA; //0xAA
        command[2] = 0x00;  //0x00
        command[3] = 0x00; //0x00
        return command;
    }
    public static short[] GetPowerPercentage(){
        Log.i(TAG, "o0x12:Get Register Content - Power Percentage command!");
        command[0] = MorSensorParameter.OUT_REGISTER_CONTENT; //0x12
        command[1] = 0xAA; //0xAA
        command[2] = 0x00;  //0x00
        command[3] = 0x2C; //0x22
        return command;
    }
    public static short[] GetPowerChargingStatus(){
        Log.i(TAG, "o0x12:Get Register Content - Power Charging Status command!");
        command[0] = MorSensorParameter.OUT_REGISTER_CONTENT; //0x12
        command[1] = 0xAA; //0xAA
        command[2] = 0x00;  //0x00
        command[3] = 0x14; //0x14
        return command;
    }
}
